public class FirstJavaProgram{
    public static void main (String[]args){
        System.out.println("My name is chamith");
        System.out.println("Im 30 years old");
        System.out.println("My home town is colombo");

    }
}